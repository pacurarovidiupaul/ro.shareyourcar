package ro.shareyourcar.dao;

public interface CarInterface {
	
	public void showFuelLevel();
	

}
