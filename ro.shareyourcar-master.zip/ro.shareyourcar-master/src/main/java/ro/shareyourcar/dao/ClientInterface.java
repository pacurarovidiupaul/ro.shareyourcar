package ro.shareyourcar.dao;

public interface ClientInterface {
	
	public void bookCar();
	public void checkWallet();
	public void showAvailableCar();
	public void pay();

}
